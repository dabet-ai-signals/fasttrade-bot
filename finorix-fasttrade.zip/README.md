# finorix-fasttrade — Full-stack starter (Demo)
This archive contains a starter full-stack project (frontend + backend) to demo a Finorix-style trading site.
Follow the README in backend and frontend folders to run locally.
