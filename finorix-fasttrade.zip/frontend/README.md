Frontend README
---------------
1. set NEXT_PUBLIC_API to your backend URL, e.g. http://localhost:4000
2. npm install
3. npm run dev
