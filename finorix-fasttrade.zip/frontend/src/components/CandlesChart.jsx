import { useEffect, useRef } from 'react';
import { createChart } from 'lightweight-charts';

export default function CandlesChart({ symbol='BTCUSDT', initData=[] }){
  const ref = useRef(null);
  const chartRef = useRef(null);
  const seriesRef = useRef(null);

  useEffect(()=>{
    chartRef.current = createChart(ref.current, { width: ref.current.clientWidth, height:520, layout:{ background: { color: '#071029' }, textColor: '#dfe7f2' } });
    seriesRef.current = chartRef.current.addCandlestickSeries({ upColor:'#26a69a', downColor:'#ef5350', borderVisible:false });
    if(initData && initData.length) seriesRef.current.setData(initData);

    const handler = (e) => {
      const c = e.detail;
      seriesRef.current.update(c);
    }
    window.addEventListener('fast:candle', handler);

    const handleResize = ()=> chartRef.current.applyOptions({ width: ref.current.clientWidth });
    window.addEventListener('resize', handleResize);

    return ()=>{
      window.removeEventListener('fast:candle', handler);
      window.removeEventListener('resize', handleResize);
      chartRef.current.remove();
    }
  }, []);

  return <div ref={ref} style={{width:'100%', height:520}} />
}
