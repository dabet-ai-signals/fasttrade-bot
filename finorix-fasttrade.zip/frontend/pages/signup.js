import { useState } from 'react';
import axios from 'axios';
import { useRouter } from 'next/router';
export default function Signup(){
  const [email,setEmail]=useState('');
  const [password,setPassword]=useState('');
  const router=useRouter();
  const submit=async(e)=>{
    e.preventDefault();
    try{
      const res=await axios.post(process.env.NEXT_PUBLIC_API+'/api/auth/signup',{email,password});
      localStorage.setItem('token',res.data.token);
      router.push('/dashboard');
    }catch(e){alert('Error')}
  }
  return (
    <main style={{padding:20}}>
      <h2>Signup</h2>
      <form onSubmit={submit}>
        <input placeholder="email" value={email} onChange={e=>setEmail(e.target.value)} />
        <input placeholder="password" type="password" value={password} onChange={e=>setPassword(e.target.value)} />
        <button type="submit">Signup</button>
      </form>
    </main>
  )
}
