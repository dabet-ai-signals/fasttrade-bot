import { useEffect, useState } from 'react';
import dynamic from 'next/dynamic';
import io from 'socket.io-client';
import axios from 'axios';

const Chart = dynamic(()=>import('../src/components/CandlesChart'),{ssr:false});

export default function Dashboard(){
  const [symbol,setSymbol]=useState('BTCUSDT');
  const [token,setToken]=useState(null);
  const [socket,setSocket]=useState(null);
  const [initData,setInitData]=useState([]);

  useEffect(()=>{ setToken(localStorage.getItem('token')) },[]);

  useEffect(()=>{
    const apiBase = process.env.NEXT_PUBLIC_API || 'http://localhost:4000';
    const s = io(apiBase.replace('/api',''),{ transports: ['websocket'] });
    setSocket(s);
    s.on('connect', ()=>{
      s.emit('subscribe',{ symbol, interval: '1m' });
    });
    s.on('klines:init', data=> setInitData(data) );
    s.on('klines:update', c => { window.dispatchEvent(new CustomEvent('fast:candle', { detail: c })) });
    return ()=> s.disconnect();
  }, [symbol]);

  const doTrade = async (side, price=0) => {
    if(!token){alert('login first');return}
    const amount = 0.001;
    try{
      const res = await axios.post((process.env.NEXT_PUBLIC_API || 'http://localhost:4000') + '/api/trades', { symbol, side, price, amount }, { headers: { Authorization: 'Bearer ' + token } });
      alert('Trade ok, new balance: ' + res.data.balance);
    }catch(e){alert('trade fail')}
  }

  return (
    <main style={{padding:20}}>
      <h2>Dashboard</h2>
      <div>
        Symbol: <select value={symbol} onChange={e=>setSymbol(e.target.value)}>
          <option>BTCUSDT</option><option>ETHUSDT</option>
        </select>
      </div>
      <div style={{marginTop:12}}>
        <button onClick={()=>doTrade('BUY')}>BUY</button>
        <button onClick={()=>doTrade('SELL')}>SELL</button>
      </div>
      <div style={{marginTop:20}}>
        <Chart symbol={symbol} initData={initData} />
      </div>
    </main>
  )
}
