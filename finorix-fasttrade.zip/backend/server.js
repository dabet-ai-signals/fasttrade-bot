require('dotenv').config();
const express = require('express');
const http = require('http');
const mongoose = require('mongoose');
const cors = require('cors');
const { Server } = require('socket.io');
const authRoutes = require('./routes/auth');
const tradesRoutes = require('./routes/trades');
const { fetchKlines } = require('./utils/binance');

const app = express();
app.use(cors());
app.use(express.json());
app.use('/api/auth', authRoutes);
app.use('/api/trades', tradesRoutes);

const server = http.createServer(app);
const io = new Server(server, { cors: { origin: '*' } });

const PORT = process.env.PORT || 4000;
const MONGODB = process.env.MONGODB_URI || 'mongodb://localhost:27017/finorix';

mongoose.connect(MONGODB).then(() => console.log('mongo ok'))
  .catch(e => console.error(e));

io.on('connection', socket => {
  console.log('ws conn');
  socket.on('subscribe', async ({ symbol = 'BTCUSDT', interval = '1m' }) => {
    try {
      const klines = await fetchKlines(symbol, interval, 200);
      socket.emit('klines:init', klines);

      const refreshMs = parseInt(process.env.BINANCE_REFRESH_MS || '60000');
      const fastOffset = parseInt(process.env.FAST_OFFSET_MS || '120000');

      const ticker = setInterval(async () => {
        try {
          const newK = await fetchKlines(symbol, interval, 3);
          const last = newK[newK.length - 1];
          const fastCandle = { ...last, time: last.time + Math.floor(fastOffset / 1000) };
          socket.emit('klines:update', fastCandle);
        } catch (e) { console.error(e); }
      }, refreshMs);

      socket.on('disconnect', () => clearInterval(ticker));
    } catch (e) { console.error(e); }
  });
});

server.listen(PORT, () => console.log('server on', PORT));
