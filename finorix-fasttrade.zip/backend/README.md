Backend README
--------------
1. copy .env.example to .env and edit MONGODB_URI and JWT_SECRET
2. npm install
3. npm run dev
