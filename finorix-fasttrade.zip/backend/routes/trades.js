const express = require('express');
const router = express.Router();
const Trade = require('../models/Trade');
const User = require('../models/User');
const jwt = require('jsonwebtoken');
const JWT_SECRET = process.env.JWT_SECRET || 'secret';

function auth(req, res, next) {
  const authHeader = req.headers.authorization;
  if (!authHeader) return res.status(401).send('No auth');
  const token = authHeader.split(' ')[1];
  try {
    const data = jwt.verify(token, JWT_SECRET);
    req.userId = data.id;
    next();
  } catch (e) { return res.status(401).send('Invalid'); }
}

router.post('/', auth, async (req, res) => {
  const { symbol, side, price, amount } = req.body;
  const trade = new Trade({ userId: req.userId, symbol, side, price, amount });
  await trade.save();
  const user = await User.findById(req.userId);
  const cost = (price || 0) * (amount || 0);
  if (side === 'BUY') user.balance -= cost; else user.balance += cost;
  await user.save();
  res.json({ ok: true, trade, balance: user.balance });
});

module.exports = router;
